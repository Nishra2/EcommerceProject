(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/76032_react-icons_hi_index_mjs_9b75c7f7._.js",
  "static/chunks/76032_react-icons_fa6_index_mjs_41d77fff._.js",
  "static/chunks/76032_react-icons_md_index_mjs_d672583d._.js",
  "static/chunks/76032_react-icons_fa_index_mjs_ad62c094._.js",
  "static/chunks/76032_react-icons_lib_c068e7e1._.js",
  "static/chunks/05397_flowbite-react_dist_esm_components_7eea80ff._.js",
  "static/chunks/05397_flowbite-react_dist_esm_e32cdb77._.js",
  "static/chunks/0c005_@floating-ui_react_dist_1c09ae5b._.js",
  "static/chunks/node_modules__pnpm_c4885d85._.js",
  "static/chunks/src_2a8e5b83._.js"
],
    source: "dynamic"
});
